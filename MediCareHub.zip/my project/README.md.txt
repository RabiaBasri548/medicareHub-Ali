RABIA BASRI
FA23-BSE-153


# MediCare Hub - Dr. Ali Waqar

This is the *homepage for MediCare Hub*, designed as part of my web development assignment.  
The website is fully *responsive, **interactive, and optimized for both **desktop and mobile* screens.

## Features

- Smooth *scrolling* and *animations* using AOS library.
- *Hover effects* on buttons, services, and links.
- Sticky *navigation bar* with current section highlighting.
- *Back-to-top button* for easy navigation.
- Static *appointment booking form*.
- Mobile-friendly layout using *TailwindCSS*.

## Tech Stack

- HTML5, CSS3
- TailwindCSS for styling
- AOS library for scroll animations

## Notes

This project is a *personal project* demonstrating responsive web design, animations, and user-friendly layout for a healthcare website.
Client Info:
Name: Ali Waqar
Qualification:MBBS
Hospital:rhc rodu sultan tehsil 18 hazari and district jhang
mail id:aliwaqar.khokhar24@gmail.com
contact nmbr of client : 03467603853
Services:Working as a general consultation and emergency management.


